import 'reterned_response.dart';

class Result {
  late ReternedResponse response;
  late Object? result;

  Result({required this.response, this.result});
}
