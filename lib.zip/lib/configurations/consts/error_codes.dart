// countryProvider getCountries Function responseBody['statu'] == false
const String ECGC100P = 'Error CGC100P';

// cityProvider getCities Function responseBody['statu'] == false
const String ECGC200P = 'Error CGC200P';

// ClientClassificationProvider getClientClassifications Function responseBody['statu'] == false
const String ECCGCC300P = 'Error ECCGCC300P';
// ClientCategoryProvider getClientCategories Function responseBody['statu'] == false
const String ECCGCC400P = 'Error ECCGCC400P';
// PlanClassProvider getPlanClasses Function responseBody['statu'] == false
const String EPCGPC500P = 'Error EPCGPC500P';

// PlanDurationProvider getPlanDurations Function responseBody['statu'] == false
const String EPDGPD600P = 'Error EPDGPD600P';
// CoinProvider getCoins Function responseBody['statu'] == false
const String ECGC700P = 'Error ECGC700P';
// PlanCostProvider getPlansCosts Function responseBody['statu'] == false
const String EPCGPC800P = 'Error EPCGPC800P';

// PaymentCategoryProvider getPaymentCategory Function responseBody['statu'] == false
const String EPCGPC900P = 'Error EPCGPC900P';

// NewMainSubscriptionProvider newSubscription Function responseBody['statu'] == false
const String ENSNS1000P = 'Error ENSNS1000P';

// NewMainSubscriptionNotificationCategoryProvider getCategories Function responseBody['statu'] == false
const String ENMSNC2000P = 'Error ENMSNC2000P';
