import 'package:flutter/material.dart';

const Color grey700 = Color(0xFF616161);
const Color grey500 = Color(0xFF9E9E9E);
const Color lightScaffoldBackgroundColor = Color(0xFFFFFFFF);
