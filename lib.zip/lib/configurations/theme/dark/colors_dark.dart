import 'package:flutter/material.dart';

import '../../consts/consts_colors.dart';

const Color grey400 = Color(0xFFBDBDBD);
const Color grey200 = Color(0xFFEEEEEE);
const Color darkScaffoldBackgroundColor = dark;
